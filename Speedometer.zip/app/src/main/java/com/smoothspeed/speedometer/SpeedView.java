package com.smoothspeed.speedometer;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.view.View;

/**
 * Speedometer drawn on a Canvas: a 270-degree gradient gauge, ticks and a big number.
 * GPS reports about once a second, so the shown value eases towards the real value
 * on every frame. This keeps the number and the gauge moving smoothly.
 */
public class SpeedView extends View {

    public static final int STATE_NO_PERMISSION = 0;
    public static final int STATE_GPS_OFF = 1;
    public static final int STATE_SEARCHING = 2;
    public static final int STATE_ACTIVE = 3;

    private static final float MAX_KMH = 250f;
    private static final float MAX_SHOWN_KMH = 999f;
    private static final float ARC_START = 135f;
    private static final float ARC_SWEEP = 270f;
    private static final float MOVING_KMH = 2f;
    private static final float SMOOTH_SECONDS = 0.40f;
    private static final int TICK_COUNT = 26;

    private static final int COLOR_BG = 0xFF05070A;
    private static final int COLOR_BG_GLOW = 0xFF0D151D;
    private static final int COLOR_TEXT = 0xFFF2F5F8;
    private static final int COLOR_MUTED = 0xFF8590A0;
    private static final int COLOR_TRACK = 0xFF151D27;
    private static final int COLOR_TICK_OFF = 0xFF2B3542;
    private static final int COLOR_LINE = 0xFF1B2430;
    private static final int COLOR_MINT = 0xFF2EE6A8;
    private static final int COLOR_CYAN = 0xFF2FC4FF;
    private static final int COLOR_VIOLET = 0xFF7B6CFF;
    private static final int COLOR_AMBER = 0xFFFFB84D;
    private static final int COLOR_RED = 0xFFFF6B6B;

    private final String strTitle;
    private final String strUnit;
    private final String strMoving;
    private final String strStanding;
    private final String strSearching;
    private final String strGpsOff;
    private final String strNoPermission;
    private final String strHintNoPermission;
    private final String strHintGpsOff;
    private final String strMaxLabel;
    private final Resources res;

    private final Paint bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arcPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tickPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint titlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint numberPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint unitPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint statusPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hintPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint valuePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private final RectF arcRect = new RectF();
    private final float[] tickLines = new float[TICK_COUNT * 4];

    private float cx;
    private float cy;
    private float radius;
    private float stroke;
    private float insetTop;
    private float insetBottom;

    private int state = STATE_SEARCHING;
    private float targetKmh = 0f;
    private float shownKmh = 0f;
    private long lastFrameNanos = 0L;

    private int shownInt = -1;
    private String shownText = "0";
    private int maxKmh = 0;
    private String maxText;

    public SpeedView(Context context) {
        super(context);
        res = context.getResources();
        strTitle = res.getString(R.string.title_speed);
        strUnit = res.getString(R.string.unit_kmh);
        strMoving = res.getString(R.string.status_moving);
        strStanding = res.getString(R.string.status_standing);
        strSearching = res.getString(R.string.status_searching);
        strGpsOff = res.getString(R.string.status_gps_off);
        strNoPermission = res.getString(R.string.status_no_permission);
        strHintNoPermission = res.getString(R.string.hint_no_permission);
        strHintGpsOff = res.getString(R.string.hint_gps_off);
        strMaxLabel = res.getString(R.string.label_max_speed);
        maxText = res.getString(R.string.value_kmh_format, 0);

        initPaints();

        setOnApplyWindowInsetsListener((v, insets) -> {
            insetTop = insets.getSystemWindowInsetTop();
            insetBottom = insets.getSystemWindowInsetBottom();
            layoutGeometry();
            invalidate();
            return insets;
        });
    }

    /** Called when the GPS state changes. Any state except ACTIVE brings the gauge back to zero. */
    public void setState(int newState) {
        if (state == newState) {
            return;
        }
        state = newState;
        if (state != STATE_ACTIVE) {
            targetKmh = 0f;
        }
        invalidate();
    }

    /** Called with every new GPS speed. Receiving a speed means GPS works. */
    public void setSpeedKmh(float kmh) {
        if (Float.isNaN(kmh) || kmh < 0f) {
            kmh = 0f;
        }
        if (kmh > MAX_SHOWN_KMH) {
            kmh = MAX_SHOWN_KMH;
        }
        state = STATE_ACTIVE;
        targetKmh = kmh;
        final int rounded = Math.round(kmh);
        if (rounded > maxKmh) {
            maxKmh = rounded;
            maxText = res.getString(R.string.value_kmh_format, maxKmh);
        }
        invalidate();
    }

    private void initPaints() {
        trackPaint.setStyle(Paint.Style.STROKE);
        trackPaint.setStrokeCap(Paint.Cap.ROUND);
        trackPaint.setColor(COLOR_TRACK);

        arcPaint.setStyle(Paint.Style.STROKE);
        arcPaint.setStrokeCap(Paint.Cap.BUTT);

        glowPaint.setStyle(Paint.Style.STROKE);
        glowPaint.setStrokeCap(Paint.Cap.BUTT);

        tickPaint.setStyle(Paint.Style.STROKE);
        tickPaint.setStrokeCap(Paint.Cap.ROUND);

        dotPaint.setStyle(Paint.Style.FILL);

        linePaint.setStyle(Paint.Style.STROKE);
        linePaint.setColor(COLOR_LINE);

        final Typeface regular = Typeface.create("sans-serif", Typeface.NORMAL);
        final Typeface medium = Typeface.create("sans-serif-medium", Typeface.NORMAL);

        titlePaint.setColor(COLOR_MUTED);
        titlePaint.setTextAlign(Paint.Align.CENTER);
        titlePaint.setTypeface(medium);
        titlePaint.setLetterSpacing(0.28f);

        numberPaint.setColor(COLOR_TEXT);
        numberPaint.setTextAlign(Paint.Align.CENTER);
        numberPaint.setTypeface(medium);
        numberPaint.setFontFeatureSettings("tnum");

        unitPaint.setColor(COLOR_MUTED);
        unitPaint.setTextAlign(Paint.Align.CENTER);
        unitPaint.setTypeface(medium);
        unitPaint.setLetterSpacing(0.22f);

        statusPaint.setColor(COLOR_TEXT);
        statusPaint.setTextAlign(Paint.Align.LEFT);
        statusPaint.setTypeface(regular);

        hintPaint.setColor(COLOR_MUTED);
        hintPaint.setTextAlign(Paint.Align.CENTER);
        hintPaint.setTypeface(regular);

        labelPaint.setColor(COLOR_MUTED);
        labelPaint.setTextAlign(Paint.Align.LEFT);
        labelPaint.setTypeface(regular);

        valuePaint.setColor(COLOR_TEXT);
        valuePaint.setTextAlign(Paint.Align.RIGHT);
        valuePaint.setTypeface(medium);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        layoutGeometry();
    }

    private void layoutGeometry() {
        final float w = getWidth();
        final float h = getHeight();
        if (w <= 0f || h <= 0f) {
            return;
        }

        final float contentH = Math.max(1f, h - insetTop - insetBottom);
        radius = Math.min(w * 0.38f, contentH * 0.27f);
        stroke = radius * 0.085f;
        cx = w / 2f;
        cy = insetTop + contentH / 2f - 0.225f * radius;
        arcRect.set(cx - radius, cy - radius, cx + radius, cy + radius);

        final float u = radius / 100f;
        titlePaint.setTextSize(u * 8.5f);
        numberPaint.setTextSize(radius * 0.66f);
        unitPaint.setTextSize(u * 9.5f);
        statusPaint.setTextSize(u * 9.5f);
        hintPaint.setTextSize(u * 7.5f);
        labelPaint.setTextSize(u * 8.5f);
        valuePaint.setTextSize(u * 10f);
        linePaint.setStrokeWidth(Math.max(1f, u * 0.5f));

        bgPaint.setShader(new RadialGradient(cx, cy, radius * 2.1f,
                COLOR_BG_GLOW, COLOR_BG, Shader.TileMode.CLAMP));

        final SweepGradient sweep = new SweepGradient(cx, cy,
                new int[]{COLOR_MINT, COLOR_CYAN, COLOR_VIOLET, COLOR_VIOLET},
                new float[]{0f, 0.375f, 0.75f, 1f});
        arcPaint.setShader(sweep);
        glowPaint.setShader(sweep);

        final float outer = radius - stroke * 1.6f;
        for (int i = 0; i < TICK_COUNT; i++) {
            final float frac = (float) i / (TICK_COUNT - 1);
            final double angle = Math.toRadians(ARC_START + frac * ARC_SWEEP);
            final float cos = (float) Math.cos(angle);
            final float sin = (float) Math.sin(angle);
            final float inner = outer - stroke * (i % 5 == 0 ? 1.15f : 0.6f);
            tickLines[i * 4] = cx + cos * inner;
            tickLines[i * 4 + 1] = cy + sin * inner;
            tickLines[i * 4 + 2] = cx + cos * outer;
            tickLines[i * 4 + 3] = cy + sin * outer;
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        final float w = getWidth();
        final float h = getHeight();
        if (w <= 0f || h <= 0f || radius <= 0f) {
            return;
        }

        final long now = System.nanoTime();
        float dt = lastFrameNanos == 0L ? 0f : (now - lastFrameNanos) / 1_000_000_000f;
        if (dt > 0.1f) {
            dt = 0.1f;
        }
        lastFrameNanos = now;
        final boolean animating = advance(dt);

        final float u = radius / 100f;

        // Background
        canvas.drawRect(0f, 0f, w, h, bgPaint);

        // Title
        final float titleY = Math.max(cy - radius * 1.30f,
                insetTop + titlePaint.getTextSize() * 2f);
        canvas.drawText(strTitle, cx, titleY, titlePaint);

        // Gauge track
        trackPaint.setStrokeWidth(stroke);
        canvas.drawArc(arcRect, ARC_START, ARC_SWEEP, false, trackPaint);

        // Ticks: the ones below the current speed are lit
        for (int i = 0; i < TICK_COUNT; i++) {
            final boolean major = i % 5 == 0;
            final boolean lit = i * 10 <= shownKmh;
            tickPaint.setStrokeWidth(radius * (major ? 0.022f : 0.014f));
            tickPaint.setColor(lit ? (major ? 0xE6FFFFFF : 0x99FFFFFF) : COLOR_TICK_OFF);
            canvas.drawLine(tickLines[i * 4], tickLines[i * 4 + 1],
                    tickLines[i * 4 + 2], tickLines[i * 4 + 3], tickPaint);
        }

        // Gauge progress with a soft glow
        final float frac = Math.min(1f, shownKmh / MAX_KMH);
        final float sweepAngle = frac * ARC_SWEEP;
        if (sweepAngle > 0.5f) {
            canvas.save();
            canvas.rotate(ARC_START, cx, cy);
            for (int i = 3; i >= 1; i--) {
                glowPaint.setStrokeWidth(stroke * (1f + i * 0.9f));
                glowPaint.setAlpha(14);
                canvas.drawArc(arcRect, 0f, sweepAngle, false, glowPaint);
            }
            arcPaint.setStrokeWidth(stroke);
            canvas.drawArc(arcRect, 0f, sweepAngle, false, arcPaint);
            canvas.restore();

            final double startAngle = Math.toRadians(ARC_START);
            dotPaint.setColor(COLOR_MINT);
            canvas.drawCircle(cx + radius * (float) Math.cos(startAngle),
                    cy + radius * (float) Math.sin(startAngle), stroke * 0.5f, dotPaint);
        }

        // Knob at the head of the gauge
        final double headAngle = Math.toRadians(ARC_START + sweepAngle);
        final float hx = cx + radius * (float) Math.cos(headAngle);
        final float hy = cy + radius * (float) Math.sin(headAngle);
        final int headColor = gradientColor(frac);
        dotPaint.setColor((headColor & 0x00FFFFFF) | 0x40000000);
        canvas.drawCircle(hx, hy, stroke * 1.35f, dotPaint);
        dotPaint.setColor(headColor);
        canvas.drawCircle(hx, hy, stroke * 0.62f, dotPaint);
        dotPaint.setColor(COLOR_TEXT);
        canvas.drawCircle(hx, hy, stroke * 0.26f, dotPaint);

        // Speed number and unit
        final int n = Math.round(shownKmh);
        if (n != shownInt) {
            shownInt = n;
            shownText = Integer.toString(n);
        }
        final float numberBaseline = cy + numberPaint.getTextSize() * 0.355f;
        canvas.drawText(shownText, cx, numberBaseline, numberPaint);
        canvas.drawText(strUnit, cx, numberBaseline + unitPaint.getTextSize() * 2.0f, unitPaint);

        // Status line: dot + text, centred together
        final float statusY = cy + radius * 0.76f;
        final String status = statusText();
        final float dotR = radius * 0.026f;
        final float gap = radius * 0.05f;
        final float textW = statusPaint.measureText(status);
        final float startX = cx - (dotR * 2f + gap + textW) / 2f;
        dotPaint.setColor(statusColor());
        canvas.drawCircle(startX + dotR, statusY - statusPaint.getTextSize() * 0.34f, dotR, dotPaint);
        canvas.drawText(status, startX + dotR * 2f + gap, statusY, statusPaint);
        final String hint = hintText();
        if (hint != null) {
            canvas.drawText(hint, cx, statusY + hintPaint.getTextSize() * 2.1f, hintPaint);
        }

        // Bottom row: label on the left, value on the right
        final float rowY = Math.min(cy + radius * 1.75f, h - insetBottom - u * 8f);
        final float side = w * 0.09f;
        canvas.drawLine(side, rowY - u * 14f, w - side, rowY - u * 14f, linePaint);
        canvas.drawText(strMaxLabel, side, rowY, labelPaint);
        canvas.drawText(maxText, w - side, rowY, valuePaint);

        if (animating) {
            postInvalidateOnAnimation();
        } else {
            lastFrameNanos = 0L;
        }
    }

    /** Moves the shown value towards the target. Returns true while it is still moving. */
    private boolean advance(float dt) {
        final float diff = targetKmh - shownKmh;
        if (Math.abs(diff) < 0.02f) {
            shownKmh = targetKmh;
            return false;
        }
        final float k = 1f - (float) Math.exp(-dt / SMOOTH_SECONDS);
        shownKmh += diff * k;
        return true;
    }

    private String statusText() {
        switch (state) {
            case STATE_NO_PERMISSION:
                return strNoPermission;
            case STATE_GPS_OFF:
                return strGpsOff;
            case STATE_SEARCHING:
                return strSearching;
            default:
                return targetKmh >= MOVING_KMH ? strMoving : strStanding;
        }
    }

    private String hintText() {
        if (state == STATE_NO_PERMISSION) {
            return strHintNoPermission;
        }
        if (state == STATE_GPS_OFF) {
            return strHintGpsOff;
        }
        return null;
    }

    private int statusColor() {
        switch (state) {
            case STATE_NO_PERMISSION:
            case STATE_GPS_OFF:
                return COLOR_RED;
            case STATE_SEARCHING:
                return COLOR_AMBER;
            default:
                return targetKmh >= MOVING_KMH ? COLOR_MINT : COLOR_MUTED;
        }
    }

    /** Colour of the gauge at a given fraction (0..1) of its length. */
    private static int gradientColor(float f) {
        if (f <= 0.5f) {
            return mix(COLOR_MINT, COLOR_CYAN, f / 0.5f);
        }
        return mix(COLOR_CYAN, COLOR_VIOLET, (f - 0.5f) / 0.5f);
    }

    private static int mix(int a, int b, float t) {
        final int r = (int) (Color.red(a) + (Color.red(b) - Color.red(a)) * t);
        final int g = (int) (Color.green(a) + (Color.green(b) - Color.green(a)) * t);
        final int bl = (int) (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t);
        return Color.rgb(r, g, bl);
    }
}
