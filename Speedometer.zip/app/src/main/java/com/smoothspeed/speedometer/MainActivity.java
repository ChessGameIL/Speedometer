package com.smoothspeed.speedometer;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.WindowManager;

public class MainActivity extends Activity {

    private static final int REQUEST_LOCATION = 100;
    private static final long UPDATE_INTERVAL_MS = 1000L;
    private static final long STALE_AFTER_MS = 5000L;
    private static final float MS_TO_KMH = 3.6f;
    private static final float NOISE_MS = 0.5f;
    private static final float MAX_SPEED_ERROR_MS = 5f;

    private final Handler handler = new Handler(Looper.getMainLooper());

    private SpeedView speedView;
    private LocationManager locationManager;
    private boolean listening = false;
    private boolean askedOnce = false;
    private boolean permanentlyDenied = false;
    private Location lastLocation;
    private long lastFixTime = 0L;

    private final LocationListener locationListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location location) {
            handleLocation(location);
        }

        @Override
        public void onProviderEnabled(String provider) {
            if (LocationManager.GPS_PROVIDER.equals(provider)) {
                speedView.setState(SpeedView.STATE_SEARCHING);
            }
        }

        @Override
        public void onProviderDisabled(String provider) {
            if (LocationManager.GPS_PROVIDER.equals(provider)) {
                lastFixTime = 0L;
                speedView.setState(SpeedView.STATE_GPS_OFF);
            }
        }

        // Must stay overridden: it is abstract on Android 8 to 10.
        @SuppressWarnings("deprecation")
        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
        }
    };

    private final Runnable staleChecker = new Runnable() {
        @Override
        public void run() {
            if (!listening) {
                return;
            }
            if (lastFixTime != 0L && SystemClock.elapsedRealtime() - lastFixTime > STALE_AFTER_MS) {
                lastFixTime = 0L;
                speedView.setState(SpeedView.STATE_SEARCHING);
            }
            handler.postDelayed(this, 1000L);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        speedView = new SpeedView(this);
        setContentView(speedView);
        speedView.setOnClickListener(v -> onScreenTap());

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (hasLocationPermission()) {
            startListening();
        } else {
            speedView.setState(SpeedView.STATE_NO_PERMISSION);
            if (!askedOnce) {
                askedOnce = true;
                requestLocationPermission();
            }
        }
    }

    @Override
    protected void onPause() {
        stopListening();
        super.onPause();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQUEST_LOCATION) {
            return;
        }
        if (hasLocationPermission()) {
            permanentlyDenied = false;
            startListening();
        } else {
            speedView.setState(SpeedView.STATE_NO_PERMISSION);
            permanentlyDenied = !shouldShowRequestPermissionRationale(
                    Manifest.permission.ACCESS_FINE_LOCATION);
        }
    }

    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void requestLocationPermission() {
        requestPermissions(new String[]{
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
        }, REQUEST_LOCATION);
    }

    private boolean isGpsEnabled() {
        return locationManager != null
                && locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
    }

    private void onScreenTap() {
        if (!hasLocationPermission()) {
            if (permanentlyDenied) {
                final Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.fromParts("package", getPackageName(), null));
                startActivitySafely(intent);
            } else {
                requestLocationPermission();
            }
        } else if (!isGpsEnabled()) {
            startActivitySafely(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
        }
    }

    private void startActivitySafely(Intent intent) {
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException ignored) {
            // No settings screen on this device: nothing else to do.
        }
    }

    @SuppressLint("MissingPermission")
    private void startListening() {
        if (listening) {
            return;
        }
        if (locationManager == null) {
            speedView.setState(SpeedView.STATE_GPS_OFF);
            return;
        }
        speedView.setState(isGpsEnabled() ? SpeedView.STATE_SEARCHING : SpeedView.STATE_GPS_OFF);
        try {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
                    UPDATE_INTERVAL_MS, 0f, locationListener);
        } catch (SecurityException e) {
            speedView.setState(SpeedView.STATE_NO_PERMISSION);
            return;
        } catch (IllegalArgumentException e) {
            // The device has no GPS provider.
            speedView.setState(SpeedView.STATE_GPS_OFF);
            return;
        }
        listening = true;
        lastFixTime = 0L;
        handler.removeCallbacks(staleChecker);
        handler.postDelayed(staleChecker, 1000L);
    }

    private void stopListening() {
        handler.removeCallbacks(staleChecker);
        if (listening && locationManager != null) {
            locationManager.removeUpdates(locationListener);
        }
        listening = false;
        lastLocation = null;
        lastFixTime = 0L;
    }

    private void handleLocation(Location loc) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                && loc.hasSpeedAccuracy()
                && loc.getSpeedAccuracyMetersPerSecond() > MAX_SPEED_ERROR_MS) {
            return;
        }

        float metersPerSecond = 0f;
        if (loc.hasSpeed()) {
            metersPerSecond = loc.getSpeed();
        } else if (lastLocation != null) {
            final float seconds = (loc.getElapsedRealtimeNanos()
                    - lastLocation.getElapsedRealtimeNanos()) / 1_000_000_000f;
            if (seconds > 0.2f) {
                metersPerSecond = lastLocation.distanceTo(loc) / seconds;
            }
        }
        lastLocation = loc;
        lastFixTime = SystemClock.elapsedRealtime();

        if (Float.isNaN(metersPerSecond) || metersPerSecond < NOISE_MS) {
            metersPerSecond = 0f;
        }
        speedView.setSpeedKmh(metersPerSecond * MS_TO_KMH);
    }
}
